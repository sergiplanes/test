<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
 <table><tr><td><img src="http://a3.twimg.com/profile_images/778122525/logot_copia_bigger.jpg" /></td><td><font size="+2"><b> El concepto detrás de MixInformatico.com</b></font></p></td></tr></table>
<p>Mixinformatico adquiere su nombre una tarde de charla con amigos de distintas tribus tecnológicas y con muchas ganas de crear un portal /blog  orientado hacia la información general sobre Internet , hoy en día somos una comunidad para todos los entusiastas de la red.</p>
<p>Generamos contenidos todos los días para informar sobre el mundo del internet, sus tecnologías, diseño, desarrollo y programación para el web e incluso hosting y manuales<br />
  ¿Quién es el Autor?</p>
<p>Mixinformatico  no tiene un autor solamente ,funciona gracias a un equipo de personas interesadas en el buen uso del Internet y que dia a dia van sumando más editores invitados.<br />
  ¿Cuándo nace el sitio?</p>
<p>Naciendo recien…. año 2009 ! Jovencito<br />
  ¿Qué encuentro en MixInformatico.com?</p>
<p>El sitio cuenta con secciones como : Scripts , Diseño , hosting , descargas , posicionamiento web , Wordpress , Joomla , noticias actuales del mundo del Internet y también una sección de ayudas en el que los usuarios postean sus necesidades y nosotros o los usuarios que puedan aportan responden .Manejamos a una comunidad con múltiples temáticas en realidad .<br />
  ¿Realizan actividades fuera de línea?</p>
<p> Si estás interesado en que apoyemos algún evento o actividad que estás organizando, no dudes en contáctarnos.<br />
  ¿Cómo puedo colaborar?</p>
<p>Muchos de nuestros visitantes se han vuelto frecuentes colaboradores enviando contenidos, reseñas y noticias de actualidad informática. Para más información no dudes en contactarnos.</p>
</body>
</html>
