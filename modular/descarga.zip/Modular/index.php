<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Ejemplo de Web Modular</title>
<style>
body{ 
padding:0; 
margin:0 auto; 
background:url(imagenes/bck.jpg) repeat-x; 
}
.principal{
padding:0; 
margin:0 auto;
width:900px; 
background:#cccccc;
border-right: 1px solid #000000;
border-left: 1px solid #000000;
}
.cuadros{
background:#ffffff; height:400px;
border-right: 1px solid #000000;
border-left: 1px solid #000000;
border-top: 1px solid #000000;
border-bottom: 1px solid #000000;
}
.link{ 
height:20px;
}
A:link {
FONT-SIZE: 13px; 
COLOR:#FF3300;
FONT-FAMILY:  arial, helvetica, verdana, sans-serif; 
text-decoration: none;
}
A:visited {
FONT-SIZE: 13px; 
COLOR:#FF3300;
FONT-FAMILY:  arial, helvetica, verdana, sans-serif; 
TEXT-DECORATION: none;
}
A:active {
FONT-SIZE: 13px; 
COLOR:#FF3300;
FONT-FAMILY:  arial, helvetica, verdana, sans-serif; 
TEXT-DECORATION: none;
}
A:hover {
font-size: 13px; 
color: #7ed9ff; 
font-family:  arial, helvetica, verdana, sans-serif; 
}

</style>
</head>
<body>
<center>
<div align="center"><img width="900" height="100" src="imagenes/header.gif" alt="Cabecera" /></div>
<div class="principal">
<table width="900" border="0" cellspacing="10" cellpadding="1">
  <tr>
    <td width="250">
    <div class="cuadros">
      <div class="link"><a href="index.php?seccion=principal"><B>Principal</B></a></div>
      <div class="link"><a href="index.php?seccion=linux"><B>Apache en Linux</B></a></div>
      <div class="link"><a href="index.php?seccion=descargar"><B>Descargar Template</B></a></div>
    </div>
    </td>
    <td>
    <div class="cuadros">
     <div style="border: 0px solid #D1D1D1; OVERFLOW-y: scroll; OVERFLOW-x: hidden; HEIGHT: 400px">

      <?
	    include("contenido.php");
	  ?>
     </div>
    </div>
    </td>
  </tr>
</table>
</div>
<table width="900" border="2" cellspacing="0" cellpadding="5">
  <tr>
    <td align="center">Copyright 2010 www.mixinformatico.com</td>
  </tr>
</table>
</center>
</body>
</html>
